CASINO EXTREME - v21 (marked)
= v20 (working) + TUNNEL SLOT FIX.
Why the tunnel was not visible: the game's control-bar UI only draws
slots 0-14 (verified in the game client source); the USA dozer tunnel
was in hidden slot 15. It is now in visible slot 12.
China dozer tunnel stays in slot 13 (visible range).

INSTALL:
1. Close the game completely (and the launcher).
2. DELETE the old map.ini and map.str from the map folder.
3. Copy this map.ini into the map folder.
4. Verify BEFORE playing: first line in Notepad must be the v21
   marker; file size must be 12,871 bytes (right-click > Properties).
5. Host.

HOW TO TEST THE TUNNEL (order matters):
1. Build a Supply Center (USA) or a War Factory (China) first -
   the tunnel unlocks after that building.
2. Select the DOZER.
3. The Tunnel Network button should now be in its build list.

Report: USA dozer tunnel visible? China dozer tunnel visible?
