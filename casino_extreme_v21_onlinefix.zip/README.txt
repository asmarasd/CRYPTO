CASINO EXTREME v21 - ONLINE TRANSFER FIX
=========================================
WHY online "Transferring Map" froze:
The game client REFUSES to transfer files that are 0 bytes.
The old package's map.str was empty (0 bytes) -> the transfer
stopped on it and your map was never delivered to players.
(Also: the client silently rejects preview images that are not
proper TGA2 files - this package includes a valid one.)

INSTALL (in the map folder):
1. Replace map.ini with this one (first line must be the v21 marker).
2. Replace map.str with this one (it now has 1 line - NOT empty).
3. Replace the preview image: copy preview.tga over your existing
   .tga file, KEEPING THE SAME FILENAME AS YOUR MAP.
   (e.g. if your map file is casino.map, the preview must be
   casino.tga - rename my preview.tga to that name.)
4. In the map folder, DELETE these files if they exist (optional
   files the game does not need - and if they are 0 bytes they
   break the transfer the same way):
   solo.ini, AssetUsage.txt, readme.txt
5. Keep ONLY in the folder: your .map file, the .tga preview,
   map.ini, map.str.

RESULT: when ANY player joins your hosted game, the game
automatically transfers: preview + map.ini + map.str + the map.
Everyone plays the same v21 casino with all features.
